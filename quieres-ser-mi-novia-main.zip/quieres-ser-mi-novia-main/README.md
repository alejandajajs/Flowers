![Captura de pantalla (2514)](https://github.com/jose9428/quieres-ser-mi-novia/assets/76067475/d7f61774-3534-44d1-9726-3c20dc50784c)
![Captura de pantalla (2515)](https://github.com/jose9428/quieres-ser-mi-novia/assets/76067475/9ea77701-2f4c-4951-af41-8b6081fc2371)
![Captura de pantalla (2517)](https://github.com/jose9428/quieres-ser-mi-novia/assets/76067475/1d6f1c17-4fb7-4cf3-a9c4-469b92921fe9)
